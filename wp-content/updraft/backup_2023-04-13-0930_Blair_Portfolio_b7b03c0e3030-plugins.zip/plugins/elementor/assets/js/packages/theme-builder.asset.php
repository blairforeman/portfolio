<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-theme-builder','deps'=>['elementor-packages-icons','elementor-packages-top-bar','elementor-packages-v1-adapters','wp-i18n',],];